#requires -Version 7.0
$Project=Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $Project 'scripts\common.ps1')
$Stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$Out=Join-Path $Project "diagnostics\$Stamp"
New-Item -ItemType Directory -Force -Path $Out|Out-Null

$r=[ordered]@{timestamp=(Get-Date).ToString('o');project=$Project;node=$null;npm=$null;ports=@();health=@{}}
if(Get-Command node -ErrorAction SilentlyContinue){$r.node=(node --version)}
if(Get-Command npm -ErrorAction SilentlyContinue){$r.npm=(npm --version)}
$corePort=Get-LocalPort $env:SKYNET_LOCAL_CORE_PORT 3000
$uiPort=Get-LocalPort $env:SKYNET_LOCAL_UI_PORT 5173
foreach($p in $corePort,$uiPort){
  $o=Get-PortOwner $p
  $r.ports+=if($o){$o | Select-Object Port,PID,Name}else{[pscustomobject]@{Port=$p;Free=$true}}
}
foreach($u in "http://127.0.0.1:$corePort/health","http://127.0.0.1:$uiPort/","http://127.0.0.1:$uiPort/health"){
  try{$x=Invoke-WebRequest $u -UseBasicParsing -NoProxy -TimeoutSec 4;$r.health[$u]=@{ok=$true;status=$x.StatusCode;type=$x.Headers['Content-Type']}}
  catch{$r.health[$u]=@{ok=$false;error=$_.Exception.Message}}
}
$r|ConvertTo-Json -Depth 10|Set-Content (Join-Path $Out 'report.json') -Encoding UTF8
$r|ConvertTo-Json -Depth 10
Write-Host "Diagnóstico: $Out" -ForegroundColor Green
