import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const backendPort = Number(process.env.SKYNET_LOCAL_CORE_PORT || 3000)
if (!Number.isInteger(backendPort) || backendPort < 1 || backendPort > 65535) {
  throw new Error('SKYNET_LOCAL_CORE_PORT inválida')
}
const backendTarget = `http://127.0.0.1:${backendPort}`
const proxy = {
  '/health': { target: backendTarget, changeOrigin: false },
  '/api': { target: backendTarget, changeOrigin: false },
  '/ws': { target: backendTarget, ws: true, changeOrigin: false },
}

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true,
    proxy,
  },
  preview: { proxy },
  build: {
    sourcemap: true,
  },
})
