'use strict';

const crypto = require('node:crypto');
const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const config = require('./core/config.cjs');
const { now, sanitizeText, uuid } = require('./core/util.cjs');
const { SessionManager } = require('./core/session-manager.cjs');
const { PacketGenerator } = require('./core/packet-generator.cjs');
const { EventStore } = require('./core/event-store.cjs');
const { OperationEngine } = require('./core/operation-engine.cjs');
const { mountScenarioLab } = require('./core/scenario-lab.cjs');

function parseArgs(argv) {
  const out = { host: config.host, port: config.port };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--host' && argv[i + 1]) out.host = String(argv[++i]);
    else if (argv[i] === '--port' && argv[i + 1]) out.port = Number(argv[++i]);
  }
  if (!Number.isInteger(out.port) || out.port < 1 || out.port > 65535) throw new Error('INVALID_PORT');
  return out;
}

function isLoopback(req) {
  return ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
}

const CLI = parseArgs(process.argv.slice(2));
const HOST = CLI.host;
const PORT = CLI.port;

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: `${Math.ceil(config.maxJsonBytes / 1024)}kb` }));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: config.wsPath, maxPayload: 256 * 1024, perMessageDeflate: false });
const sessions = new SessionManager();
const packetGenerator = new PacketGenerator();
const store = new EventStore(config);

function sendWs(client, event) {
  if (client.readyState !== WebSocket.OPEN || client.bufferedAmount > 256 * 1024) return;
  try {
    client.send(JSON.stringify(event));
    store.metrics.wsMessagesOut += 1;
  } catch {
    store.metrics.errors += 1;
  }
}

function broadcast(event) {
  for (const client of wss.clients) sendWs(client, event);
}

const engine = new OperationEngine({ packetGenerator, sessions, store, broadcast, maxBurst: config.operationBurstMax });

app.use((req, res, next) => {
  const started = process.hrtime.bigint();
  res.on('finish', () => store.audit({
    type: 'HTTP', method: req.method, path: req.path, status: res.statusCode,
    elapsedMs: Number(process.hrtime.bigint() - started) / 1e6, timestamp: now(),
  }));
  next();
});

// Current project contract: a loopback-only, session-isolated synthetic lab.
mountScenarioLab(app);

app.get(['/health', '/api/health'], (_req, res) => {
  res.json({ ok: true, service: 'skynet-v8-lucifer-core', version: config.version, host: HOST, port: PORT, pid: process.pid, uptimeSeconds: Math.floor(process.uptime()), websocketPath: config.wsPath, websocketClients: wss.clients.size, queue: engine.status() });
});

app.get('/api/state', (_req, res) => {
  res.json({ ok: true, version: config.version, websocketClients: wss.clients.size, sessions: sessions.list(), queue: engine.status(), ...store.snapshot() });
});

app.get('/api/metrics', (_req, res) => {
  res.json({ ok: true, process: { pid: process.pid, uptimeSeconds: Math.floor(process.uptime()) }, websocketClients: wss.clients.size, queue: engine.status(), metrics: store.metrics });
});

app.post('/api/ws-session', (req, res) => {
  if (!isLoopback(req)) return res.status(403).json({ ok: false, error: 'LOCAL_ORIGIN_REQUIRED' });
  res.cookie('skynet_ws', crypto.randomBytes(32).toString('hex'), { httpOnly: true, sameSite: 'strict', path: config.wsPath, maxAge: 60000 });
  return res.set('Cache-Control', 'no-store').json({ ok: true, scope: 'LOCAL_SYNTHETIC_ONLY' });
});

app.post('/api/session', (req, res) => {
  const session = sessions.create(sanitizeText(req.body?.label || 'dashboard', 80));
  const event = { type: 'SESSION_CREATED', sid: session.sid, sessionId: session.id, timestamp: now() };
  store.pushEvent(event);
  broadcast(event);
  res.status(201).json({ ok: true, session });
});

app.post('/api/packet', (req, res) => {
  const format = sanitizeText(req.body?.format || 'socketio', 32).toLowerCase();
  const event = sanitizeText(req.body?.event || 'lab.test', 80);
  const data = typeof req.body?.data === 'object' && req.body.data && !Array.isArray(req.body.data) ? req.body.data : {};
  const packet = format === 'binary' ? packetGenerator.makeBinary(event, data) : packetGenerator.makeSocketIo(event, data);
  store.pushEvent({ type: 'PACKET_GENERATED', format: packet.format, bytes: packet.bytes, sha256: packet.sha256, timestamp: now() });
  res.json({ ok: true, packet });
});

app.post('/api/mutate', (req, res) => {
  const frame = sanitizeText(req.body?.frame || '', 4000);
  const strategy = sanitizeText(req.body?.strategy || 'flip-char', 32);
  res.json({ ok: true, strategy, input: frame, mutated: packetGenerator.mutateText(frame, strategy) });
});

app.post('/api/operation', (req, res) => {
  const input = req.body || {};
  if (['provider', 'vector'].some(key => input[key] !== undefined && typeof input[key] !== 'string')) return res.status(400).json({ ok: false, error: 'INVALID_OPERATION_FIELD' });
  const intensity = input.intensity ?? 25;
  if (!Number.isInteger(intensity) || intensity < 1 || intensity > config.operationBurstMax) return res.status(400).json({ ok: false, error: 'INVALID_OPERATION_INTENSITY' });
  const job = engine.enqueue({ provider: sanitizeText(input.provider || 'PGSOFT', 32).toUpperCase(), vector: sanitizeText(input.vector || 'RACE_CONDITION', 64).toUpperCase(), intensity });
  res.status(202).json({ ok: true, status: 'QUEUED', job });
});

app.post('/api/observe-site', (req, res) => {
  const observation = { type: 'SITE_OBSERVATION', id: uuid(), provider: sanitizeText(req.body?.provider || 'UNKNOWN', 32), game: sanitizeText(req.body?.game || 'UNKNOWN', 96), host: sanitizeText(req.body?.host || '', 96), pathname: sanitizeText(req.body?.pathname || '', 240), title: sanitizeText(req.body?.title || '', 160), timestamp: now() };
  store.pushObservation(observation);
  store.pushEvent(observation);
  broadcast(observation);
  res.json({ ok: true, observation });
});

app.post('/api/reset-lab', (req, res) => {
  if (!isLoopback(req)) return res.status(403).json({ ok: false, error: 'LOCAL_ORIGIN_REQUIRED' });
  sessions.reset();
  store.events.length = 0;
  store.operations.length = 0;
  store.persist();
  broadcast({ type: 'LAB_RESET', timestamp: now() });
  res.json({ ok: true });
});

wss.on('connection', (socket, req) => {
  if (!isLoopback(req)) return socket.close(1008, 'LOCAL_ORIGIN_REQUIRED');
  socket.isAlive = true;
  socket.on('pong', () => { socket.isAlive = true; });
  sendWs(socket, { type: 'CONNECTED', service: 'skynet-v8-lucifer-core', version: config.version, timestamp: now() });
  socket.on('message', (data, isBinary) => {
    store.metrics.wsMessagesIn += 1;
    if (isBinary) return sendWs(socket, { type: 'BINARY_ACK', bytes: data.length, timestamp: now() });
    const text = String(data);
    if (text === 'PING') return sendWs(socket, { type: 'PONG', timestamp: now() });
    if (text.startsWith('42')) {
      let parsed = null;
      try { parsed = JSON.parse(text.slice(2)); } catch {}
      return sendWs(socket, { type: parsed ? 'SOCKETIO_FRAME_PARSED' : 'SOCKETIO_FRAME_INVALID', parsed, timestamp: now() });
    }
    return sendWs(socket, { type: 'ECHO', text: sanitizeText(text, 500), timestamp: now() });
  });
});

wss.on('error', error => { store.metrics.errors += 1; console.error('[WS ERROR]', error); });
const heartbeat = setInterval(() => {
  for (const socket of wss.clients) {
    if (socket.isAlive === false) { try { socket.terminate(); } catch {} continue; }
    socket.isAlive = false;
    try { socket.ping(); } catch {}
  }
}, 12000);
heartbeat.unref();

app.use((error, _req, res, next) => {
  if (res.headersSent) return next(error);
  if (error.type === 'entity.parse.failed') return res.status(400).json({ ok: false, error: 'INVALID_JSON' });
  if (error.type === 'entity.too.large') return res.status(413).json({ ok: false, error: 'PAYLOAD_TOO_LARGE' });
  store.metrics.errors += 1;
  console.error('[HTTP ERROR]', error);
  return res.status(500).json({ ok: false, error: 'INTERNAL_ERROR' });
});

server.on('error', error => {
  store.metrics.errors += 1;
  if (error?.code === 'EADDRINUSE') { console.error(`[SKYNET V8 LUCIFER] Porta ${PORT} já está em uso.`); process.exitCode = 98; return; }
  console.error('[SERVER ERROR]', error);
  process.exitCode = 1;
});

function shutdown(signal) {
  console.log(`[SKYNET V8 LUCIFER] ${signal}: encerrando.`);
  clearInterval(heartbeat);
  try { store.persist(); } catch {}
  for (const client of wss.clients) { try { client.close(1001, 'shutdown'); } catch {} }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 4000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
server.listen(PORT, HOST, () => {
  console.log(`[SKYNET V8 LUCIFER] Core ${config.version} online em http://${HOST}:${PORT}`);
  console.log(`[SKYNET V8 LUCIFER] WebSocket ws://${HOST}:${PORT}${config.wsPath}`);
});
