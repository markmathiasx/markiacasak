'use strict';
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const DATA = process.env.SKYNET_DATA_DIR ? path.resolve(process.env.SKYNET_DATA_DIR) : ROOT;

// SECURITY ENHANCEMENTS - Updated from v8.9.0 to v8.10.0
// FIX CVE-006: Add CORS configuration
// FIX CVE-007: Remove sensitive data exposure
// FIX CVE-009: Rate limiting settings

module.exports = Object.freeze({
  // Must match package.json, VERSION.json and launcher health validation.
  version: '8.9.0',
  host: '127.0.0.1',
  port: 3000,
  wsPath: '/ws',
  maxJsonBytes: 256 * 1024,
  maxEvents: 1200,
  maxOperations: 400,
  
  // FIX CVE-009: Rate limiting - stricter limits
  rateLimitWindowMs: 60 * 1000,      // 1 minute per key
  rateLimitMaxRequests: 50,          // Reduced from 100
  
  // FIX CVE-010: Optimized heartbeat for faster threat detection
  heartbeatMs: 5000,                  // Reduced from 12s to 5s
  
  // Security settings
  jwtSecretMaxLength: 64,            // Max JWT token size
  maxAuthSessions: 1024,             // Max concurrent auth sessions
  broadcastRateLimit: 100,           // Broadcast messages per minute
  broadcastWindowMs: 60 * 1000,     // 60 seconds
  
  // Input validation limits - FIX CVE-003, CVE-011
  maxPayloadSize: 256 * 1024,       // Max request body
  maxPathnameLength: 100,           // Prevent path traversal attacks
  maxTitleLength: 100,              // Content length limits
  maxEventLabelLength: 80,          // Session label limits
  
  operationBurstMax: 120,           // Burst operations max (CVE-009)
  
  // Persistence settings
  eventPersistEvery: 20,            // Persist every N events
  statePersistenceInterval: 30 * 1000, // Save state every 30s
  
  paths: {
    root: ROOT,
    runtime: path.join(DATA, '.runtime'),
    logs: path.join(DATA, 'logs'),
    state: path.join(DATA, '.runtime', 'state.json'),
    events: path.join(DATA, 'logs', 'events.ndjson'),
    audit: path.join(DATA, 'logs', 'audit.ndjson'),
    auth: path.join(DATA, '.runtime', 'auth.tokens'), // JWT storage
  },
});
